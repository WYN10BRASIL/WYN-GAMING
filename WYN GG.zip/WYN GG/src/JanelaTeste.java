/**
 * @author Willyan Walker;
 */
public class JanelaTeste {

    public static void main(String[] args) throws Exception{
        Janela janela = new Janela();
         System.out.println(janela);
         System.out.println("Hello World");
    }
}